import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.html',
  styleUrls: ['./login.sass']
})
export class Login implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
